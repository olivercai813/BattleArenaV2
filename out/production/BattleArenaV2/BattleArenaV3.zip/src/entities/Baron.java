package entities;

import game.GamePanel;

import java.awt.*;

public class Baron extends BaseEntity {
    private final static int RADIUS = 200;
    private final static int MAX_HP = 100;
    private final static int DAMAGE = 10;
    private final static int ATTACK_RANGE = 400;
    private final static double ATTACK_SPEED = 0.2;
    private final static int PROJECTILE_SPEED = 4;

    public Baron (GamePanel gamePanel, double x, double y) {
        super(gamePanel, GamePanel.ENEMY, x, y, RADIUS, MAX_HP, DAMAGE, ATTACK_RANGE, ATTACK_SPEED, PROJECTILE_SPEED);
    }

    @Override
    public void update() {
        findTarget();
        useBasicAttack();
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(new Color(153, 0, 76));
        super.draw(g);
        g.setColor(new Color(153, 0, 76));
        g.fillOval((int)(x-radius),(int)(y-radius), radius*2, radius*2);
    }
}
