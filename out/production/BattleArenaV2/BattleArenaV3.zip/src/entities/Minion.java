package entities;

import game.GamePanel;

public abstract class Minion extends MovingEntity {
    protected int bounty;
    private static final int RADIUS = 30;
    private final static double ATTACK_SPEED = 0.5;
    private static final int MOVEMENT_SPEED = 2;

    public Minion(GamePanel gamePanel, int team, double x, double y, int maxHP, int damage, int attackRange, int bounty, int projectileSpeed) {
        super(gamePanel, team, x, y, RADIUS, maxHP, damage, attackRange, ATTACK_SPEED, MOVEMENT_SPEED, projectileSpeed);
        this.bounty = bounty;
    }

    @Override
    public void update() {
        findTarget();
        useBasicAttack();
        move();
    }

}
