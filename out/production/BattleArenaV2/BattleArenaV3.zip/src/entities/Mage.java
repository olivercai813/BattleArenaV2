package entities;

import attacks.BasicAttack;
import game.GamePanel;
import java.awt.*;

public class Mage extends Champion {
    private static final int RADIUS = 20;
    private static final int MAX_HP = 100;
    private static final int ATTACK_RANGE = 400;
    private static final double ATTACK_SPEED = 0.5;
    private static final int MOVEMENT_SPEED = 4;
    private static final int PHYSICAL_DMG = 1;
    private final static int PROJECTILE_SPEED = 5;


    public Mage(GamePanel gamePanel, double x, double y) {
        super(gamePanel, x, y, RADIUS, MAX_HP, PHYSICAL_DMG, ATTACK_RANGE, ATTACK_SPEED, MOVEMENT_SPEED,PROJECTILE_SPEED,0,0,0, 0);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.white);
        super.draw(g);
        g.setColor(Color.blue);
        g.fillOval((int)(x-radius),(int)(y-radius), (int)radius*2, (int)radius*2);
    }
}
