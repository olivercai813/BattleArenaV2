package entities;

import attacks.BasicAttack;
import game.GamePanel;
import java.awt.*;

public abstract class Champion extends MovingEntity {

    protected int healthRegen;
    protected int abilityHaste;
    protected int physicalDamage;
    protected int magicDamage;
    protected int lifeSteal;
    protected boolean showRange;

    public Champion(GamePanel gamePanel, double x, double y, int radius, int maxHP, int physicalDamage, int attackRange, double attackSpeed, int movementSpeed, int projectileSpeed, int healthRegen,
                    int abilityHaste, int magicDamage, int lifeSteal) {
        super(gamePanel, GamePanel.ALLY, x, y, radius, maxHP, physicalDamage, attackRange, attackSpeed, movementSpeed, projectileSpeed);
        this.healthRegen = healthRegen;
        this.abilityHaste = abilityHaste;
        this.physicalDamage = physicalDamage;
        this.magicDamage = magicDamage;
        this.lifeSteal = lifeSteal;
        showRange = false;
    }

    public void setMoveTarget(Point moveTarget) {
        this.movePoint = moveTarget;
        attackTarget = null;
    }

    public void setAttackTarget(BaseEntity attackTarget) {
        if (rangeIntersects(attackTarget.getX(),attackTarget.getY(),attackTarget.getRadius())) {
            movePoint = null;
        }
        this.attackTarget = attackTarget;
    }

    @Override
    public void update() {
        checkClick();
        checkKey();
        useBasicAttack();
        move();
    }

    //must set move before setting attack because move overrides attack
    private void checkClick() {
        Point clickPoint = gamePanel.mouseHandler.getClickPoint();
        if (clickPoint != null) {
            setMoveTarget(clickPoint);
            for (BaseEntity enemy : gamePanel.enemyGameEntities) {
                if (enemy.objectIntersects(clickPoint.getX(),clickPoint.getY(),0)) {
                    setAttackTarget(enemy);
                }
            }
        }
    }

    private void checkKey() {
        showRange = gamePanel.keyHandler.AKeyPressed();
        if (gamePanel.keyHandler.SKeyPressed()) {
            movePoint = null;
        }
    }

    @Override
    public void useBasicAttack() {
        if (basicAttack == null && attackTarget != null && rangeIntersects(attackTarget.getX(),attackTarget.getY(),attackTarget.getRadius())
                && (gamePanel.time - previousAttackTime) >= attackCooldown) {
            previousAttackTime = gamePanel.time;
            basicAttack = new BasicAttack(physicalDamage, this.x, this.y, attackTarget, projectileSpeed);
        } else if (basicAttack != null) {
            if (basicAttack.getTarget() != null ) {
                basicAttack.move();
            } else {
                attackTarget = null;
                basicAttack = null;
            }
        }
    }

    @Override
    public void move() {
        if (movePoint != null) {
            double denominator = Math.sqrt(Math.pow((movePoint.x - this.x), 2) + Math.pow((movePoint.y - this.y), 2));

            if (denominator != 0) {
                double xStep = ((movePoint.x - this.x) / denominator) * movementSpeed;
                double yStep = ((movePoint.y - this.y) / denominator) * movementSpeed;

                boolean colliding = false;
                if (gamePanel.enemyGameEntities.contains(this)) {
                    for (BaseEntity entity : gamePanel.allyGameEntities) {
                        if (entity != this && entity.objectIntersects(x + xStep, y + yStep, radius)) {
                            colliding = true;
                        }
                    }
                } else {
                    for (BaseEntity entity : gamePanel.enemyGameEntities) {
                        if (entity != this && entity.objectIntersects(x + xStep, y + yStep, radius)) {
                            colliding = true;
                        }
                    }
                }

                if (colliding || (attackTarget != null && rangeIntersects(attackTarget.getX(),attackTarget.getY(),attackTarget.getRadius()))) {
                    movePoint = null;
                } else if (Math.abs(movePoint.x - this.x) < Math.abs(xStep) || Math.abs(movePoint.y - this.y) < Math.abs(yStep)) {
                    this.x = movePoint.x;
                    this.y = movePoint.y;
                    movePoint = null;
                } else {
                    this.x += xStep;
                    this.y += yStep;
                }
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
        if (showRange) {
            g.setColor(new Color(200,255,255));
            g.drawOval((int)(x-attackRange),(int)(y-attackRange), (int)attackRange*2, (int)attackRange*2);
            g.setColor(new Color(0,51,51,80));
            g.fillOval((int)(x-attackRange)+5,(int)(y-attackRange)+5, (int)attackRange*2-10, (int)attackRange*2-10);
        }
    }
}
