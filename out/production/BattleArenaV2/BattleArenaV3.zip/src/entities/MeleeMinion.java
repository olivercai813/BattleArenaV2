package entities;

import game.GamePanel;
import java.awt.*;

public class MeleeMinion extends Minion {

    private static final int MAX_HP = 18;
    private static final int DAMAGE = 1;
    private static final int ATTACK_RANGE = 40;
    private static final int BOUNTY = 0;
    private static final int PROJECTILE_SPEED = ATTACK_RANGE;


    public MeleeMinion(GamePanel gamePanel, int team, double x, double y) {
        super(gamePanel, team, x, y, MAX_HP, DAMAGE, ATTACK_RANGE, BOUNTY, PROJECTILE_SPEED);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.red);
        super.draw(g);
        g.setColor(Color.white);
        g.fillOval((int)(x-radius),(int)(y-radius), radius*2, radius*2);
//        g.drawOval((int)(x-attackRange),(int)(y-attackRange), attackRange*2, attackRange*2);
    }
}