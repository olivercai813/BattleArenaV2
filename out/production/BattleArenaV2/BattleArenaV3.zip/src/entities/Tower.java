package entities;

import game.GamePanel;
import java.awt.*;

public class Tower extends BaseEntity {
    private final static int RADIUS = 30;
    private final static int MAX_HP = 30;
    private final static int DAMAGE = 6;
    private final static int ATTACK_RANGE = 300;
    private final static int PROJECTILE_SPEED = 8;
    private final static double ATTACK_SPEED = 1.0;

    public Tower(GamePanel gamePanel, double x, double y) {
        super (gamePanel, GamePanel.ENEMY, x, y, RADIUS, MAX_HP, DAMAGE, ATTACK_RANGE, ATTACK_SPEED, PROJECTILE_SPEED);
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    @Override
    public void update() {
        findTarget();
        useBasicAttack();
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.red);
        super.draw(g);
        g.setColor(Color.red);
        g.drawOval((int)(x-attackRange),(int)(y-attackRange), (int)attackRange*2, (int)attackRange*2);
        g.setColor(new Color(51,0,0, 80));
        g.fillOval((int)(x-attackRange)+5,(int)(y-attackRange)+5, (int)attackRange*2-10, (int)attackRange*2-10);
        g.setColor(Color.red);
        g.fillOval((int)(x-radius),(int)(y-radius), (int)radius*2, (int)radius*2);
    }
}
