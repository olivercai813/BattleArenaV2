package entities;

import attacks.BasicAttack;
import game.GamePanel;
import java.awt.*;

public class Fighter extends Champion {
    private static final int RADIUS = 40;
    private static final int MAX_HP = 300;
    private static final int ATTACK_RANGE = 70;
    private static final double ATTACK_SPEED = 1;
    private static final int MOVEMENT_SPEED = 4;
    private static final int PHYSICAL_DMG = 2;
    private final static int PROJECTILE_SPEED = ATTACK_RANGE;

    public Fighter(GamePanel gamePanel, double x, double y) {
        super(gamePanel, x, y, RADIUS, MAX_HP, PHYSICAL_DMG, ATTACK_RANGE, ATTACK_SPEED, MOVEMENT_SPEED,PROJECTILE_SPEED,0,0,0, 0);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.white);
        super.draw(g);
        g.setColor(Color.green);
        g.fillOval((int)(x-radius),(int)(y-radius), (int)radius*2, (int)radius*2);
    }
}