package entities;

import attacks.*;
import game.GamePanel;
import java.awt.*;

public abstract class BaseEntity {

    protected GamePanel gamePanel;
    protected int team;
    protected double x;
    protected double y;
    protected int radius;
    protected int currentHP;
    protected int maxHP;
    protected int attackRange;
    protected double attackSpeed;
    protected int projectileSpeed;
    protected int damage;
    protected BaseEntity attackTarget;
    protected BasicAttack basicAttack;
    protected long attackCooldown;
    protected long previousAttackTime;

    public BaseEntity(GamePanel gamePanel, int team, double x, double y, int radius, int maxHP, int damage, int attackRange, double attackSpeed, int projectileSpeed) {
        this.gamePanel = gamePanel;
        this.team = team;
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.maxHP = maxHP;
        this.damage = damage;
        this.attackRange = attackRange;
        this.attackSpeed = attackSpeed;
        this.projectileSpeed = projectileSpeed;
        currentHP = maxHP;
        attackCooldown = (long)(1000000000/this.attackSpeed);
        previousAttackTime = 0;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public int getRadius() {
        return this.radius;
    }

    public boolean isDefeated() {
        return currentHP == 0;
    }

    public void findTarget() {
        int targetIndex = 0;
        double distance;
        double minDistance = Integer.MAX_VALUE;

        if (team == GamePanel.ALLY) {
            for (int i = 0; i < gamePanel.enemyGameEntities.size(); i++) {
                distance = Math.sqrt(Math.pow(this.x - gamePanel.enemyGameEntities.get(i).getX(), 2) + Math.pow(this.y - gamePanel.enemyGameEntities.get(i).getY(), 2));
                if (distance < minDistance) {
                    minDistance = distance;
                    targetIndex = i;
                }
            }
            attackTarget = gamePanel.enemyGameEntities.get(targetIndex);
        } else {
            for(int i = 0; i < gamePanel.allyGameEntities.size(); i++) {
                distance = Math.sqrt(Math.pow(this.x - gamePanel.allyGameEntities.get(i).getX(), 2) + Math.pow(this.y - gamePanel.allyGameEntities.get(i).getY(), 2));
                if (distance < minDistance) {
                    minDistance = distance;
                    targetIndex = i;
                }
            }
            attackTarget = gamePanel.allyGameEntities.get(targetIndex);
        }
    }

    public boolean objectIntersects(double otherX, double otherY, double otherRadius) {
        double distance = Math.sqrt(Math.pow(this.x - otherX, 2) + Math.pow(this.y - otherY, 2));
        return distance <= this.radius - otherRadius || distance <= otherRadius - this.radius
                || distance < this.radius + otherRadius || distance == this.radius + otherRadius;
    }

    public boolean rangeIntersects(double otherX, double otherY, double otherRadius) {
        double distance = Math.sqrt(Math.pow(this.x - otherX, 2) + Math.pow(this.y - otherY, 2));
        return distance <= this.attackRange - otherRadius || distance <= otherRadius - this.attackRange
                || distance < this.attackRange + otherRadius || distance == this.attackRange + otherRadius;
    }

    public abstract void update();

    public void useBasicAttack() {
        if (basicAttack == null && attackTarget != null && rangeIntersects(attackTarget.getX(),attackTarget.getY(),attackTarget.getRadius())
                && (gamePanel.time - previousAttackTime) >= attackCooldown) {
            previousAttackTime = gamePanel.time;
            basicAttack = new BasicAttack(damage, x, y, attackTarget, projectileSpeed);
        } else if (basicAttack != null){
            if (basicAttack.getTarget() != null) {
                basicAttack.move();
            } else {
                basicAttack = null;
            }
        }
    }

    public void takeDamage(int damage) {
        if (currentHP - damage <= 0) {
            currentHP = 0;
        } else {
            currentHP -= damage;
        }
    }

    public void draw(Graphics g) {
        if (basicAttack != null) {
            basicAttack.draw(g);
        }
        if (team == GamePanel.ALLY) {
            g.setColor(new Color(255,255,0, 200));
        } else {
            g.setColor(new Color(204,0,0,200));
        }
        g.drawRect((int)(this.x-50), (int)(getY()-radius-30), 100, 10);
        g.fillRect((int)(this.x-50), (int)(getY()-radius-30), (int)(100*currentHP*1.0/maxHP), 10);
    }
}
