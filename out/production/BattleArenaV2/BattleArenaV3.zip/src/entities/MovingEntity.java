package entities;

import game.GamePanel;
import java.awt.*;

public abstract class MovingEntity extends BaseEntity {
    protected int movementSpeed;
    protected Point movePoint;
    protected BaseEntity moveTarget;

    public MovingEntity(GamePanel gamePanel, int team, double x, double y, int radius, int maxHP, int damage, int attackRange, double attackSpeed, int movementSpeed, int projectileSpeed) {
        super(gamePanel, team, x, y, radius, maxHP, damage, attackRange, attackSpeed, projectileSpeed);
        this.movementSpeed = movementSpeed;
    }

    @Override
    public void findTarget() {
        super.findTarget();
        moveTarget = attackTarget;
    }

    public void move() {
        if (moveTarget != null && !rangeIntersects(moveTarget.getX(), moveTarget.getY(), moveTarget.getRadius())) {
            double denominator = Math.sqrt(Math.pow((moveTarget.x - this.x), 2) + Math.pow((moveTarget.y - this.y), 2));

            if (denominator != 0) {
                double xStep = ((moveTarget.x - this.x) / denominator) * movementSpeed;
                double yStep = ((moveTarget.y - this.y) / denominator) * movementSpeed;

                boolean colliding = false;

                if (gamePanel.enemyGameEntities.contains(this)) {
                    for (BaseEntity entity : gamePanel.allyGameEntities) {
                        if (entity != this && entity.objectIntersects(x + xStep, y + yStep, radius)) {
                            colliding = true;
                            break;
                        }
                    }
                } else {
                    for (BaseEntity entity : gamePanel.enemyGameEntities) {
                        if (entity != this && entity.objectIntersects(x + xStep, y + yStep, radius)) {
                            colliding = true;
                            break;
                        }
                    }
                }

                if (!colliding) {
                    this.x += xStep;
                    this.y += yStep;
                }
            }
        }
    }
}
