package attacks;

import entities.*;

import java.awt.*;

public class BasicAttack extends Projectile {
    private final static int RADIUS = 5;

    public BasicAttack(int damage, double x, double y, BaseEntity target, double projectileSpeed) {
        super(damage, x, y, target, projectileSpeed);
    }

    @Override
    public void move() {
        double otherX = target.getX();
        double otherY = target.getY();

        if (target != null && (otherX != this.x || otherY != this.y)) {
            double denominator = Math.sqrt(Math.pow((otherX - this.x), 2) + Math.pow((otherY - this.y), 2));

            if (denominator != 0) {
                double xStep = ((otherX - this.x) / denominator) * projectileSpeed;
                double yStep = ((otherY - this.y) / denominator) * projectileSpeed;

                if (Math.abs(otherX - this.x) < Math.abs(xStep) || Math.abs(otherY - this.y) < Math.abs(yStep) || target.objectIntersects(this.x, this.y, 0)) {
                    this.x = otherX;
                    this.y = otherY;
                    target.takeDamage(damage);
                    target = null;
                } else {
                    this.x += xStep;
                    this.y += yStep;
                }
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        g.fillOval((int)(x-RADIUS),(int)(y-RADIUS), RADIUS*2, RADIUS*2);
    }
}
