package attacks;

import entities.*;
import java.awt.*;

public abstract class Ability {
    protected int damage;
    protected double x;
    protected double y;
    protected BaseEntity target;

    public Ability (int damage, double x, double y, BaseEntity target) {
        this.damage = damage;
        this.x = x;
        this.y = y;
        this.target = target;
    }

    public void setTarget(BaseEntity target) {
        this.target = target;
    }

    public BaseEntity getTarget() {
        return this.target;
    }

    public abstract void draw(Graphics g);
}
