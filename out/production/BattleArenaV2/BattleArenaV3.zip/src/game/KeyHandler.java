package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {
    private boolean AKeyPressed;
    private boolean SKeyPressed;

    public boolean AKeyPressed() {
        return AKeyPressed;
    }

    public boolean SKeyPressed() {
        return SKeyPressed;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_A) {
            AKeyPressed = true;
        } else if (e.getKeyCode() == KeyEvent.VK_S) {
            SKeyPressed = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_A) {
            AKeyPressed = false;
        } else if (e.getKeyCode() == KeyEvent.VK_S) {
            SKeyPressed = false;
        }
    }
}
