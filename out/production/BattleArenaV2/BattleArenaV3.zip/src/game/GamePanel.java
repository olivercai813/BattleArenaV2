package game;

import entities.*;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class GamePanel extends JPanel implements Runnable {

    public static final int GAME_WIDTH = 1536;
    public static final int GAME_HEIGHT = 864;
    public static final int ALLY = 0;
    public static final int ENEMY = 1;
    private static final Point PLAYER_SPAWN = new Point(GAME_WIDTH/10, GAME_HEIGHT/2);
    private static final Point BARON_SPAWN = new Point(19*GAME_WIDTH/20, GAME_HEIGHT/2);
    private static final Point ALLY_MINION_SPAWN_1 = new Point(-GAME_WIDTH/10,GAME_HEIGHT/10);
    private static final Point ALLY_MINION_SPAWN_2 = new Point(-GAME_WIDTH/10,9*GAME_HEIGHT/10);
    private static final Point ENEMY_MINION_SPAWN_1 = new Point((int)(GAME_WIDTH*11.0/10),GAME_HEIGHT/10);
    private static final Point ENEMY_MINION_SPAWN_2 = new Point((int)(GAME_WIDTH*11.0/10),9*GAME_HEIGHT/10);
    private static final Point ENEMY_MINION_SPAWN_3 = new Point((int)(GAME_WIDTH*12.0/10),GAME_HEIGHT/10);
    private static final Point ENEMY_MINION_SPAWN_4 = new Point((int)(GAME_WIDTH*12.0/10),9*GAME_HEIGHT/10);
    private static final Point TOWER_SPAWN = new Point(6*GAME_WIDTH/10, GAME_HEIGHT/2);


    private Thread gameThread;

    public ArrayList<BaseEntity> allyGameEntities;
    public ArrayList<BaseEntity> enemyGameEntities;
    public long time;
    public MouseHandler mouseHandler = new MouseHandler();
    public KeyHandler keyHandler = new KeyHandler();
    private Champion player;
    public int framesPerSecond;
    private boolean mouseChanged;

    public GamePanel() {
        this.setPreferredSize(new Dimension(GAME_WIDTH,GAME_HEIGHT));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addMouseListener(mouseHandler);
        this.addKeyListener(keyHandler);
        this.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon("src/images/NewCursor.png").getImage(), new Point(0,0),"custom cursor"));
        createEntities();
    }

    private void createEntities() {
        player = new Fighter(this,PLAYER_SPAWN.getX(), PLAYER_SPAWN.getY());
        allyGameEntities = new ArrayList<>();
        enemyGameEntities = new ArrayList<>();
        allyGameEntities.add(player);
        enemyGameEntities.add(new Tower(this,TOWER_SPAWN.getX(), TOWER_SPAWN.getY()));
        enemyGameEntities.add(new Baron(this, BARON_SPAWN.getX(), BARON_SPAWN.getY()));
        allyGameEntities.add(new MeleeMinion(this, ALLY, ALLY_MINION_SPAWN_1.getX(),ALLY_MINION_SPAWN_1.getY()));
        allyGameEntities.add(new MeleeMinion(this, ALLY, ALLY_MINION_SPAWN_2.getX(),ALLY_MINION_SPAWN_2.getY()));
        enemyGameEntities.add(new MeleeMinion(this, ENEMY, ENEMY_MINION_SPAWN_1.getX(),ENEMY_MINION_SPAWN_1.getY()));
        enemyGameEntities.add(new MeleeMinion(this, ENEMY, ENEMY_MINION_SPAWN_2.getX(),ENEMY_MINION_SPAWN_2.getY()));
        enemyGameEntities.add(new RangedMinion(this, ENEMY, ENEMY_MINION_SPAWN_3.getX(), ENEMY_MINION_SPAWN_3.getY()));
        enemyGameEntities.add(new RangedMinion(this, ENEMY, ENEMY_MINION_SPAWN_4.getX(), ENEMY_MINION_SPAWN_4.getY()));
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {

        double FPS = 60.0;
        double drawInterval = 1000000000/FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while(gameThread != null) {
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime)/drawInterval;
            timer += currentTime - lastTime;
            lastTime = System.nanoTime();

            if (delta >= 1) {
                time = currentTime;
                update();
                repaint();
                delta--;
                drawCount++;
            }

            if (timer >= 1000000000) {
                System.out.println("FPS: " + drawCount);
                framesPerSecond = drawCount;
                drawCount = 0;
                timer = 0;
            }
        }
    }

    public void update() {
        checkKey();
        for (BaseEntity ally: allyGameEntities) {
            ally.update();
        }

        for (BaseEntity enemy: enemyGameEntities) {
            enemy.update();
        }
        despawn();
    }

    private void checkKey() {
        if (keyHandler.AKeyPressed()) {
            mouseChanged = true;
            this.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon("src/images/TargetCursor.png").getImage(),
            new Point(Toolkit.getDefaultToolkit().getBestCursorSize(250, 250).height/2,
            Toolkit.getDefaultToolkit().getBestCursorSize(250, 250).width/2),"custom cursor"));
        } else if (mouseChanged) {
            mouseChanged = false;
            this.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon("src/images/NewCursor.png").getImage(),
            new Point(0,0),"custom cursor"));
        }
    }

    private int getRandomNum(int min, int max) {
        return (int)(Math.random()*(max-min+1)+min);
    }

    private void despawn() {

        BaseEntity current;
        ArrayList<BaseEntity> newGameEntities = new ArrayList<>();
        Iterator<BaseEntity> iter = allyGameEntities.iterator();
        while (iter.hasNext()) {
            current = iter.next();
            if (current.isDefeated()) {
                if (current instanceof Champion) {
                    System.out.println("DEAD :(");
                } else if (current instanceof MeleeMinion) {
                    iter.remove();
                    if (getRandomNum(0,1) == 0) {
                        newGameEntities.add(new MeleeMinion(this, ALLY, ALLY_MINION_SPAWN_1.getX(),ALLY_MINION_SPAWN_1.getY()));
                    } else {
                        newGameEntities.add(new MeleeMinion(this, ALLY, ALLY_MINION_SPAWN_2.getX(),ALLY_MINION_SPAWN_2.getY()));
                    }
                }
            }
        }
        allyGameEntities.addAll(newGameEntities);

        newGameEntities.clear();
        iter = enemyGameEntities.iterator();
        while (iter.hasNext()) {
            current = iter.next();
            if (current.isDefeated()) {
                iter.remove();
//               if (current instanceof Tower) {
//                    iter.add(new Tower(this, TOWER_SPAWN.getX(), TOWER_SPAWN.getY()));
                if (current instanceof MeleeMinion) {
                    if (getRandomNum(0,1) == 0) {
                        newGameEntities.add(new MeleeMinion(this, ENEMY, ENEMY_MINION_SPAWN_1.getX(),ENEMY_MINION_SPAWN_1.getY()));
                    } else {
                        newGameEntities.add(new MeleeMinion(this, ENEMY, ENEMY_MINION_SPAWN_2.getX(), ENEMY_MINION_SPAWN_2.getY()));
                    }
                } else if (current instanceof RangedMinion) {
                    if (getRandomNum(0,1) == 0) {
                        newGameEntities.add(new RangedMinion(this, ENEMY, ENEMY_MINION_SPAWN_3.getX(),ENEMY_MINION_SPAWN_3.getY()));
                    } else {
                        newGameEntities.add(new RangedMinion(this, ENEMY, ENEMY_MINION_SPAWN_4.getX(), ENEMY_MINION_SPAWN_4.getY()));
                    }
                }
            }
        }
        enemyGameEntities.addAll(newGameEntities);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        ArrayList<BaseEntity> enemies = new ArrayList<>(enemyGameEntities);
        for (BaseEntity enemy : enemies) {
            enemy.draw(g);
        }
        ArrayList<BaseEntity> allies = new ArrayList<>(allyGameEntities);
        for (BaseEntity ally : allies) {
            ally.draw(g);
        }
        g.setColor(Color.white);
        g.drawString("FPS: " + framesPerSecond, GAME_WIDTH-70, 20);
    }
}
