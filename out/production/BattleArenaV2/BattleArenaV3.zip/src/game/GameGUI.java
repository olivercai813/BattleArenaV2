package game;

import java.awt.*;

public class GameGUI {
    GamePanel gamePanel;

    public GameGUI(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    public void draw(Graphics g) {
        g.setColor(Color.white);
        g.drawString("FPS: " + gamePanel.framesPerSecond, GamePanel.GAME_WIDTH-70, 20);
    }
}
